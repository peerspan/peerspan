Validation evidence for the historical comparison source.
The Rust tests log includes an earlier clippy failure during test-module development; the later Rust clippy log records the resolved passing check.
Publication checks on current main are recorded separately in the PR.
Runtime fixture keys and executable files are not included.
